# DHT12 library Arduino

Hi
